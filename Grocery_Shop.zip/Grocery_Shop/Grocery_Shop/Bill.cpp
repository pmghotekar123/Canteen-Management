#include "User_Info.h"
#include "Shop.h"
#include "Bill.h"

void Bill::print_bill()
{
    int j = 1;
    int i = 1;
    cout << "\n==========================================================================================\n";
    cout << "                           -----   Balaji Grossery Shop   -----                             \n";
    cout << "==========================================================================================\n";
    cout << "------------------------------------------------------------------------------------------\n";
    cout << "      Name and Mobile Number : " << name << "  |  " << mobile << "                       \n";
    cout << "|-----------------------------------------------------------------------------------------|\n";
    cout << "|  Sr. No.  |       Name of the Item       |     Quantity    |     Rate    |     Amount   |\n";
    cout << "|-----------|------------------------------|-----------------|-------------|--------------|\n";
    if (product_quantity[j - 1])
    {
        cout << "|     " << i << "     |      " << shop_items[j - 1] << "       |      " << product_quantity[j - 1] << "\t|      " << set_price[j - 1] << "\t|    " << amount[j - 1] << "\t|\n";
        i++;
    }
    j++;

    if (product_quantity[j - 1])
    {
        cout << "|     " << i << "     |      " << shop_items[j - 1] << "\t\t\t   |      " << product_quantity[j - 1] << "\t|      " << set_price[j - 1] << "\t|    " << amount[j - 1] << "\t|\n";
        i++;
    }
    j++;

    if (product_quantity[j - 1])
    {
        cout << "|     " << i << "     |      " << shop_items[j - 1] << "\t\t   |      " << product_quantity[j - 1] << "\t|      " << set_price[j - 1] << "\t|    " << amount[j - 1] << "\t|\n";
        i++;
    }
    j++;

    if (product_quantity[j - 1])
    {
        cout << "|     " << i << "     |      " << shop_items[j - 1] << "\t\t   |      " << product_quantity[j - 1] << "\t|      " << set_price[j - 1] << "\t|    " << amount[j - 1] << "\t|\n";
        i++;
    }
    j++;

    if (product_quantity[j - 1])
    {
        cout << "|     " << i << "     |      " << shop_items[j - 1] << "\t\t   |      " << product_quantity[j - 1] << "\t|      " << set_price[j - 1] << "\t|    " << amount[j - 1] << "\t|\n";
        i++;
    }
    j++;

    cout << "|           |                              |    \n";
    cout << "|           |                              |    \n";
    cout << "|-----------------------------------------------------------------------------------------\n";
    cout << "|                                                                   TOTAL : " << total_bill << endl;
    cout << "------------------------------------------------------------------------------------------\n";
}
