#ifndef __User_Info
#define __User_Info

#include <bits/stdc++.h>

using namespace std;
typedef long long int ll;

class User_Info
{
public:
    string name;
    ll mobile;
    void Information();
    void display();
};

#endif
