#include "User_Info.h"

void User_Info::Information()
{
    cout << "Enter your Name : ";
    cin >> name;
    cout << "Enter your Mobile number : ";
    cin >> mobile;
}
void User_Info::display()
{
    cout << "Your Entered Name and Mobile number is : " << name << " and " << mobile << endl;
}
