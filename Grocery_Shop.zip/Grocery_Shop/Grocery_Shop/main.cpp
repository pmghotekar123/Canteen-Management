#include <bits/stdc++.h>
#include "User_Info.h"
#include "Shop.h"
#include "Bill.h"


using namespace std;
typedef long long int ll;

int main()
{
    Bill ABC;
    ABC.Information();
    ABC.user_items();
    ABC.print_bill();
    
    return 0;
}