#include "Shop.h"
#include "User_Info.h"

void Shop::showitem()
{
    cout << "---------------------------------------------------------------\n";
    for (int i = 0; i < 5; i++)
    {
        cout << i + 1 << ". " << shop_items[i] << " | ";
    }
    cout << "\nEnter number infront of the item to add" << endl;
    cout << "Press 0 to exit and Print Bill" << endl;
}
void Shop::user_items()
{
    do
    {
        showitem();
        float temp_price, temp_quantity;
        cin >> product_code;
        if ((product_code == 1) || (product_code == 4))
        {
            cout << "Enter the Quantity of " << shop_items[product_code - 1] << " you want : ";
            cin >> temp_quantity;
            temp_price = temp_quantity * set_price[product_code - 1] * 1.0;
            cout << "Do you want to add " << temp_quantity << " items of " << shop_items[product_code - 1] << " at the rate of " << set_price[product_code - 1] << " per item" << endl;
            cout << "Press 1 to add  |  Press 0 Cancel : ";
            int x;
            cin >> x;
            if (x == 1)
            {
                total_bill = total_bill + temp_price;
                amount[product_code - 1] = amount[product_code - 1] + temp_price;
                product_quantity[product_code - 1] = product_quantity[product_code - 1] + temp_quantity;
            }
        }
        else if ((product_code == 2) || (product_code == 3) || (product_code == 5))
        {
            cout << "Enter the Quantity of " << shop_items[product_code - 1] << " you want (in grams) : ";
            cin >> temp_quantity;
            temp_price = (temp_quantity / 1000) * set_price[product_code - 1] * 1.0;
            cout << "Do you want to add " << ((temp_quantity * 1.0) / 1000) << " kg of " << shop_items[product_code - 1] << " at the rate of " << set_price[product_code - 1] << "/kg" << endl;
            cout << "Press 1 to add  |  Press 0 Cancel : ";
            int x;
            cin >> x;
            if (x == 1)
            {
                total_bill = total_bill + temp_price;
                amount[product_code - 1] = amount[product_code - 1] + temp_price;
                product_quantity[product_code - 1] = product_quantity[product_code - 1] + (temp_quantity * 1.0 / 1000);
            }
        }
        else if (product_code == 0)
        {
        }
        else
        {
            cout << "Invalid Input\n";
        }
    } while (product_code);
    cout << endl;
}