#ifndef __Bill
#define __Bill

#include <bits/stdc++.h>
#include "User_Info.h"
#include "Shop.h"

using namespace std;
typedef long long int ll;

class Bill : public Shop
{
public:
    void print_bill();
};

#endif
