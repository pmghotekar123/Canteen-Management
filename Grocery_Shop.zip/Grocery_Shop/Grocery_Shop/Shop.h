#ifndef __Shop
#define __Shop

#include <bits/stdc++.h>
#include "User_Info.h"

using namespace std;
typedef long long int ll;

class Shop : public User_Info
{
public:
    int product_code;
    float set_price[5] = {25, 50, 27, 10, 35}, total_bill = 0, amount[5] = {0}, product_quantity[5] = {0};
    string shop_items[5] = {"Soap", "Rice", "Wheat", "Toothpaste", "Sugar"};
    void showitem();
    void user_items();
};

#endif
